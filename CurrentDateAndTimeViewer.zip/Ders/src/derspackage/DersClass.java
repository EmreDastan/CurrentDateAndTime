package derspackage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DersClass {
	
	public static void main(String[] args) {
		
		Date currentdate = new Date();
		SimpleDateFormat Timeformatter = new SimpleDateFormat("hh.mm.ss");
		SimpleDateFormat dateformatter = new SimpleDateFormat("dd.MM.yyyy");
		System.out.println("Current time is : " + Timeformatter.format(currentdate));
		System.out.println("Current date is : " + dateformatter.format(currentdate));
	}
}